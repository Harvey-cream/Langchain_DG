declare module 'sm-crypto';
